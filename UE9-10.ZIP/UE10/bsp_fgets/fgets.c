// Beispiel für fgets

#include <stdio.h>

int main()
{
	char text[100]; // Platz für Eingabe
	printf("\nGeben Sie einen Text ein:\n");
	text = fgets(text,10,stdin);
	//scanf("%s",text);
	printf("Eingabe:%s %s\n",r,text);
	return 0;
}
